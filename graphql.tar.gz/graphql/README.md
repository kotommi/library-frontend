.env format:
MONGODB_URI="db url"
JWT_SECRET="secret phrase"